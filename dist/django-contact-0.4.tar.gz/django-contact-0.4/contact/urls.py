from django.conf.urls.defaults import patterns, url


urlpatterns = patterns(
    'contact.views',
    
    url(r'thanks/', 'thanks', name="contact_thanks"),
    url(r'', 'index', name="contact_index"),
)